/********* MupConfig.m Cordova Plugin Implementation *******/

#import <Cordova/CDV.h>
#import <AddtionsKit/AddtionsKit.h>
#import <LoginServiceKit/LoginServiceKit.h>
#import <CommunityServiceKit/YGCommunityService.h>

@interface MupConfig : CDVPlugin {
  // Member variables go here.
}

- (void)init:(CDVInvokedUrlCommand*)command;
@end

@implementation MupConfig

- (void)init:(CDVInvokedUrlCommand *)command {
    // 初始化 navigation
    [self setupStatusBar];
    [self setupNavigationBar];

    NSString *arg0 = [command argumentAtIndex:0];
    if (arg0 != nil && arg0.length > 0) {
        NSDictionary *dict = [NSDictionary initWithJsonString:arg0];
        MessageServiceServerHost = [[NSMutableString alloc] initWithString:dict[@"messageHost"]];
        WebsocketServerHost = [[NSMutableString alloc] initWithString:dict[@"socketHost"]];
        MUPServiceServerHost = [[NSMutableString alloc] initWithString:dict[@"mupHost"]];
    }

    // init user info
    NSString *arg1 = [command argumentAtIndex:1];
    if (arg1 != nil && arg1.length > 0) {
        NSDictionary *dict = [NSDictionary initWithJsonString:arg1];
        [YGUserInfoModel saveWithData:dict];
    }

    // 设置全局头像
    [YGGlobalVariable sharedInstance].imageDelegate = [YGCommunityService sharedInstance];

    //崩溃日志监听
    [[YGLogManager sharedInstance] beginLogCrash];
    [[YGLogManager sharedInstance] addLoggers];

    // 回调
    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"config finished!"];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)setupStatusBar {
    UIApplication.sharedApplication.statusBarStyle = UIStatusBarStyleLightContent;
}

- (void)setupNavigationBar {

    NSDictionary *attributes = @{NSForegroundColorAttributeName: GlobalNavigationBarBarTintColor,
                                 NSFontAttributeName: [UIFont boldSystemFontOfSize:GlobalNavigationBarFontSize]
                                 };

    [UINavigationBar appearance].tintColor = GlobalNavigationBarTintColor;
    [UINavigationBar appearance].barTintColor = GlobalNavigationBarBarTintColor;
    //设置导航标题属性
    [UINavigationBar appearance].titleTextAttributes = attributes;
    //设置导航背景色

    if (![[UINavigationBar appearance] backgroundImageForBarMetrics:UIBarMetricsDefault]) {
        UIImage *image = [UIImage imageNamed:@"navigationBarBackgroundImage"];
        if (!image) {
            image = [UIImage imageWithColor:GlobalNavigationBarBackgroundColor];
        }
        [[UINavigationBar appearance] setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    }
}

@end
