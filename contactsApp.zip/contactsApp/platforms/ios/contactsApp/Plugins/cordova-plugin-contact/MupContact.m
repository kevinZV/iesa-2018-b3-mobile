/********* MupContact.m Cordova Plugin Implementation *******/

#import <Cordova/CDV.h>
#import <ContactsKit/YGMainOrgViewController.h>
#import <CommunityServiceKit/YGCommunityService.h>
#import <CommunityServiceKit/YGMessageDataSourceCommunity.h>
#import <AddtionsKit/AddtionsKit.h>

@interface MupContact : CDVPlugin {
  // Member variables go here.
}

- (void)open:(CDVInvokedUrlCommand*)command;
@end

@implementation MupContact

- (void)init:(CDVInvokedUrlCommand*)command {

    NSString *arg = [command argumentAtIndex:0];
    NSDictionary *dict = [NSDictionary initWithJsonString:arg];

    // 设置头像代理
    [YGGlobalVariable sharedInstance].imageDelegate = [YGCommunityService sharedInstance];

    // 是否支持协作伙伴
    [YGContactsFactroy sharedInstance].contactConfig.supportPartner = dict[@"supportPartner"] ? [dict[@"supportPartner"] boolValue] : NO;
    // 是否支持客户
    [YGContactsFactroy sharedInstance].contactConfig.supportCustom = dict[@"supportCustom"] ? [dict[@"supportCustom"] boolValue] : NO;

    // 设置联系人数据源
    [YGContactsFactroy sharedInstance].dataSource = [YGContactsDataSourceCommunity sharedInstance];

    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"init contacts finished"];

    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

/**
 打开联系人主页

 @param command command description
 */
- (void)open:(CDVInvokedUrlCommand *)command {

    YGMainOrgViewController *vc = [[YGMainOrgViewController alloc] init];
    vc.title = @"通讯录";
    vc.hidesBottomBarWhenPushed = YES;
    if (self.viewController.navigationController) {
        [self.viewController.navigationController pushViewController:vc animated:YES];
    } else {
        UINavigationController *navgationController = [[UINavigationController alloc] initWithRootViewController:vc];
        [self.viewController presentViewController:navgationController animated:YES completion:nil];
    }

    CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:@"open contact sucess!"];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}
@end
