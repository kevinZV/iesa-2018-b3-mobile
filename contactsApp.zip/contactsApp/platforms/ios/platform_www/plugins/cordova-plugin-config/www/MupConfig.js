cordova.define("cordova-plugin-config.MupConfig", function(require, exports, module) {
var exec = require('cordova/exec');

/** 
 * 配置插件，主要配置网络接口和用户数据
 */
var MupConfig = function(){};

/**
 * initParams:
 * var params = new Object();
    params.messageHost = 'https://xxx.com';
    params.socketHost = 'wss://xxx.com';
    params.mupHost = '';
    params.logEnabled = true;
    params.crashEnabled = true;
    initParams = JSON.stringify(params);
 * @param  {} initParams json string, key: 参见 params
 * @param  {} userInfo userInfo json string, 如果使用MupLogin，则不需要传此参数
 * @param  {} success
 * @param  {} error
 */
MupConfig.init = function (initParams, userInfo, success, error) {
    exec(success, error, 'MupConfig', 'init', [initParams, userInfo]);
};

module.exports = MupConfig;
});
