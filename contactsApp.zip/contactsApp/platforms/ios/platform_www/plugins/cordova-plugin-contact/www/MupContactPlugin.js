cordova.define("cordova-plugin-contact.MupContactPlugin", function(require, exports, module) {
var exec = require('cordova/exec');

/**
 * 联系人插件
 */
var MupContactPlugin = function(){};

/**
 * 初始化基础库，如果初始化过不需要再度初始化
 * @param initParams 初始化信息 server、imgServer、wsServer、mupId、cookie、ccid、 ccName;
 * @param userInfo 用户信息
 */
MupContactPlugin.initBasePlugin = function (successCallback, errorCallback, initParams, userInfo) {
    exec(successCallback, errorCallback, "MupContactPlugin", "initBasePlugin",[initParams, userInfo]);
};

/**
 * 初始化通讯录
 */
MupContactPlugin.init = function (successCallback, errorCallback) {
    exec(successCallback, errorCallback, "MupContactPlugin", "init", "");
};

/**
 * 打开通讯录主页
 */
MupContactPlugin.open = function (successCallback, errorCallback, openParams) {
    exec(successCallback, errorCallback, "MupContactPlugin", "open", "");
};

module.exports = MupContactPlugin;
});
