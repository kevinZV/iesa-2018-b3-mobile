import{ Contact, Contacts ContactFindOptions, ContactFieldType, ContactName,ContactField } from '@ionic-native/contacts';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {

  }

}
