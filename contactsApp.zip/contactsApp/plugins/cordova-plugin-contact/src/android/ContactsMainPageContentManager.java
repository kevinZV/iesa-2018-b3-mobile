package com.ygsoft.contact;

import android.support.v4.app.Fragment;

import com.ygsoft.tt.contacts.fragment.ContactsListFragment;


/**
 * 通讯录主页内容FragmentUI管理器
 * Created by wangjun4 on 2017/5/22.
 */

public class ContactsMainPageContentManager {
    /**
     * 创建通讯录主页内容Fragment实例
     *
     * @return
     */
    public static Fragment newInstance() {
        return new ContactsListFragment();
    }
}
