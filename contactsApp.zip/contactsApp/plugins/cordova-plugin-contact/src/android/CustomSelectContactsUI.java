package com.ygsoft.contact;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ygsoft.tt.contacts.global.TTContactsConfigInfo;
import com.ygsoft.tt.contacts.global.TTContactsConst;
import com.ygsoft.tt.contacts.vo.ContactsClassifyVo;
import com.ygsoft.tt.selectcontacts.global.ICustomSelectContactsUI;

import java.util.List;

/**
 * 通讯录数据类型转换器
 * <p>
 * Created by wangjun4 on 2017/11/13.
 */
public class CustomSelectContactsUI implements ICustomSelectContactsUI {

    private Context context;

    public CustomSelectContactsUI(Context context) {
        this.context = context;
    }

    @Override
    public void insertItemToHeaderView(Context context, LinearLayout parentView) {
        //插入“我的群组”
        ContactsClassifyVo item1 = new ContactsClassifyVo();
        item1.setClassifyId(TTContactsConst.MYGROUP_ORG_ID);
        item1.setClassifyName("我的群组");
        item1.setClassifyResId(com.ygsoft.tt.contacts.R.drawable.selectcontacts_listview_header_item_mygroup_icon);
        View myGroupItem = LayoutInflater.from(context).inflate(com.ygsoft.tt.contacts.R.layout.selectcontacts_listview_header_item, null);
        ((ImageView) myGroupItem.findViewById(com.ygsoft.tt.contacts.R.id.selectcontacts_listview_header_item_icon)).setImageResource(item1.getClassifyResId());
        ((TextView) myGroupItem.findViewById(com.ygsoft.tt.contacts.R.id.selectcontacts_listview_header_item_name)).setText(item1.getClassifyName());
        myGroupItem.setTag(item1);
        parentView.addView(myGroupItem);
    }

    @Override
    public void insertItemToContactsClassifyListView(List<ContactsClassifyVo> dataList) {
        if (TTContactsConst.INTERNAL_CONTACTS_ORG_ID.equals(TTContactsConfigInfo.getInstance().getContactsClassifyId(this.context))) {
            //本人为企业通讯录用户
            //插入“内部通讯录”
            ContactsClassifyVo item1 = new ContactsClassifyVo();
            item1.setClassifyId(TTContactsConst.INTERNAL_CONTACTS_ORG_ID);
            item1.setClassifyName("企业通讯录");
            item1.setClassifyResId(com.ygsoft.tt.contacts.R.drawable.selectcontacts_internalcontacts_icon);
            dataList.add(item1);
        } else {
            //本人为非企业通讯录用户
            return;
        }
    }
}
