package com.ygsoft.contact;


import com.ygsoft.tt.contacts.global.IContactsConverter;
import com.ygsoft.tt.contacts.vo.ContactsDbVo;
import com.ygsoft.tt.contacts.vo.OrgDbVo;

import java.util.List;

/**
 * 通讯录数据类型转换器
 * Created by wangjun4 on 2017/11/13.
 */
public class ContactsConvertor implements IContactsConverter {
    @Override
    public List<OrgDbVo> convert2OrgList(Object resObj) {
        return null;
    }

    @Override
    public List<ContactsDbVo> convert2ContactsList(Object resObj) {
        return null;
    }
}
