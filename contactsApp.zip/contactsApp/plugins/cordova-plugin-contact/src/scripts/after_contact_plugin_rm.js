var fs = require('fs');
var path = require('path');
var rootdir = process.argv[2];

console.log("res_message rootdir " + rootdir)

if (rootdir && process.argv[4] === 'cordova-plugin-contact') {
    try {
        var fullfilenPath = path.join(rootdir, '../platforms/android/app/src/main/res_contact');
        console.log("res_contact dirs path " + fullfilenPath)
        if (fs.existsSync(fullfilenPath)) {
            console.log("res_contact dirs exits")
            deleteall(fullfilenPath)
        } else {
            console.log("res_contact dirs don't exits")
        }

        /*var dbPath = path.join(rootdir, '../platforms/android/app/src/main/assets/db');
        console.log("res_contact db dirs path " + dbPath)
        if (fs.existsSync(dbPath)) {
            console.log("res_contact db exits")
            deleteall(dbPath)
        } else {
            console.log("res_contact db dirs don't exits")
        }*/

    } catch (e) {
        console.log(e)
        //process.stdout.write(e);
    }
    function deleteall(path) {
        var files = [];
        if(fs.existsSync(path)) {
            files = fs.readdirSync(path);
            files.forEach(function(file, index) {
                var curPath = path + "/" + file;
                if(fs.statSync(curPath).isDirectory()) { // recurse
                    deleteall(curPath);
                } else { // delete file
                    fs.unlinkSync(curPath);
                }
            });
            fs.rmdirSync(path);
        }
    }
}


