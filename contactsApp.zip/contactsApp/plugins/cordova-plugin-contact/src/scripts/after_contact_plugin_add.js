var fs = require('fs');
var path = require('path');
var rootdir = process.argv[2];

console.log("res_contact rootdir " + rootdir)

//if (rootdir && process.argv[4] === 'cordova-plugin-contact') {
if (rootdir && process.argv[4].toLowerCase().indexOf("contact") !== -1) {

    try {
        //替换build.gradle文件内容
        var resGradlePath = path.join(rootdir, '../platforms/android/build.gradle');
        if (fs.existsSync(resGradlePath)) {
            replace_string_in_file(resGradlePath, "res.srcDirs = ['res']", "res.srcDir 'res'");
        } else {
            console.log("missing: " + resGradlePath);
        }
    } catch (e) {
        console.log(e)
        process.stdout.write(e);
    }

    try {
        var litePalPath = path.join(rootdir, '../platforms/android/assets/litepal.xml');
        var source = path.join(rootdir, '../plugins/cordova-plugin-contact/src/android/xml/litepal.xml');
        console.log("res_contact litepal source path " + source)
        console.log("res_contact litepal dirs path " + litePalPath)
        if (fs.existsSync(litePalPath)) {
            console.log("res_contact litepal dirs exits")
        } else {
            copy(source , litePalPath)
            console.log("litePalPath litepal dirs copy")
        }

        var fulldbPath = path.join(rootdir, '../platforms/android/assets/db/locations.db');
        var fulldbPathDir = path.join(rootdir, '../platforms/android/assets/db');
        var sourcebd = path.join(rootdir, '../plugins/cordova-plugin-contact/src/android/db/locations.db');
        console.log("res_contact db source path " + sourcebd)
        console.log("res_contact db dirs path " + fulldbPath)
        if (fs.existsSync(fulldbPath)) {
            console.log("res_contact db dirs exits")
        } else {
            if (!fs.existsSync(fulldbPathDir)) {
                fs.mkdirSync(fulldbPathDir)
            }
            copy(sourcebd , fulldbPath)
            console.log("res_contact db dirs copy")
        }


        var fullRawPath = path.join(rootdir, '../platforms/android/res/raw/expression_config.xml');
        var fullRawPathDir = path.join(rootdir, '../platforms/android/res/raw');
        var sourceRaw = path.join(rootdir, '../plugins/cordova-plugin-contact/src/android/xml/expression_config.xml');

        console.log("res_contact raw source path " + sourceRaw)
        console.log("res_contact raw dirs path " + fullRawPath)
        if (fs.existsSync(fullRawPath)) {
            console.log("res_contact raw dirs exits")
        } else {
            if (!fs.existsSync(fullRawPathDir)) {
                fs.mkdirSync(fullRawPathDir)
            }
            copy(sourceRaw , fullRawPath)
            console.log("res_contact raw dirs copy")
        }

    } catch (e) {
        console.log(e)
    }
    /**MultiDex Change**/
    try {
        var manifestPath = path.join(rootdir, '../platforms/android/AndroidManifest.xml');
        //判断AndroidManifest.xml文件是否存在
        if (fs.existsSync(manifestPath)) {
            var data2 = fs.readFileSync(manifestPath, 'utf8');
            if (data2.indexOf("multidex") === -1) {
                replace_string_in_file(manifestPath, "<application", '<application android:name="android.support.multidex.MultiDexApplication"');
            } else {
                console.log("manifest multidex application had init ");
            }
        } else {
            console.log("missing: " + manifestPath);
        }
        //替换build.gradle文件内容
        var gradlePath = path.join(rootdir, '../platforms/android/build.gradle');
        if (fs.existsSync(gradlePath)) {
            var data = fs.readFileSync(gradlePath, 'utf8');
            if (data.indexOf("multidex") === -1) {
                replace_string_in_file(gradlePath, /defaultConfig\s*\{/gi, 'defaultConfig {\n multiDexEnabled true');
                replace_string_in_file(gradlePath, /}\s*dependencies\s*\{/gi, '}\n dependencies {\n compile "com.android.support:multidex:1.0.0"');
            } else {
                console.log("multidex had init ");
            }
        } else {
            console.log("missing: " + gradlePath);
        }

    } catch (e) {
        process.stdout.write(e);
    }



    function copy(src, dst) {
        fs.writeFileSync(dst, fs.readFileSync(src));
    }
    //正则表达式替换文本
    function replace_string_in_file(filename, to_replace, replace_with) {
        var data = fs.readFileSync(filename, 'utf8');
        console.log(to_replace)
        console.log(replace_with)
        var result = data.replace(to_replace, replace_with);
        fs.writeFileSync(filename, result, 'utf8');
    }
}

