
通讯录和联系人插件


## Android 插件使用

#### 打开通讯录主页，请确保已经通过登录插件登录成功。没登录需直接调用初始化插件。
```
 cordova.plugins.MupContactPlugin.open((e) => {
            }, (e) => {
                console.log(e)
            }, "")
```

#### 初始化基础插件，如果已经使用登录插件登录，可忽略
```
//服务器返回的用户信息，主要包含有用户id，用户名，用户姓名，用户性别，用户头像等字段
var userInfo = "{\"regUserType\":\"WINDOW\",\"authChanel\":\"mup\",\"userId\":\"9ddacc179d704cd8844d2b7372f93e39\",\"loginName\":\"guoshuyu\",\"userName\":\"郭树煜\",\"password\":\"e10adc3949ba59abbe56e057f20f883e\",\"sex\":0,\"userType\":2,\"userRole\":0,\"mobile\":\"15889964368\",\"email\":\"guoshuyu@ygsoft.com\",\"tel\":\"0\",\"userPicId\":\"5a1383a57e568a614f6c603a\",\"userOrg\":[{\"orgId\":\"177f0ace22ec42bd89e48cf62c596d03\",\"orgName\":\"远光软件股份有限公司 - 公司本部 - 远光研究院 - 企业互联网实验室\",\"subOrg\":false,\"postName\":\"开发人员\",\"orgType\":0,\"orgLevel\":0,\"categoryId\":0,\"orderNo\":0,\"nums\":0,\"isWeChatOrg\":0,\"openPermissionFlag\":0,\"select\":false}],\"errorCode\":0,\"userDataType\":1,\"updateDate\":1518314132772,\"userEmailState\":0,\"createTask\":true,\"createChannel\":false,\"createGroup\":false,\"manageChannel\":false,\"createSpace\":true,\"manageDimCode\":false,\"auditItemSchedule\":false,\"isOnline\":1,\"currentCompanyCode\":\"af7412e63d1b44629ebcd4ac3c234986\",\"groupCompanyCode\":\"fa04840e91db433fbc3a380d3a8eeb94\",\"companyCodeVos\":[{\"companyCode\":\"af7412e63d1b44629ebcd4ac3c234986\",\"companyName\":\"远光软件股份有限公司\",\"isUserPermission\":true}],\"pwdSecRemind\":false,\"accessToken\":\"ae9615f5a5543fcc3417b4248a997eaa\",\"labels\":[{\"labelId\":\"20160624150557057kw6ur94\",\"labelName\":\"产品\"},{\"labelId\":\"2018010414291901927fg78a\",\"labelName\":\"6666\"},{\"labelId\":\"20180211090506006z2b1sj2\",\"labelName\":\"打不开\"}],\"hasUserPic\":1,\"favorApps\":[\"55da109544dd423b9b91feb39fe3ea87\",\"c8c4d57ce87b4f5ea83e0552544a953f\",\"ca00a59210b5401dab238aa764554711\",\"c3123ebbd59248f884d8dd721c566a35\",\"33a83583aac2497aaa1c6a2bce50ec62\",\"ec737f66d08c474d9cfbf163cc42fb51\",\"d0eb686ea1d84642b4aec06ecb25c83f\",\"1caecd667ddd47518d33f190c87243f9\",\"f0634ab7e8f4493a8441cecd7a582702\",\"adf491548a6d48c88c161de838bccbcd\",\"909ce6c78c7d4d8e8f1a89d4122a90c5\",\"35f675c488fc4f7e8c2a0532c01fac05\"],\"stop\":false,\"partner\":false,\"externalUser\":false,\"orgId\":\"177f0ace22ec42bd89e48cf62c596d03\",\"editInfo\":false,\"authenticated\":true,\"spaceManager\":false,\"manager\":false,\"needLoginCode\":false,\"userOrgs\":\"远光软件股份有限公司 - 公司本部 - 远光研究院 - 企业互联网实验室/开发人员\"}";
//配置信息
var configInfo = "{\"server\":\"http://10.51.111.101/webapp/\",\"imgServer\":\"http://10.51.111.101/webapp/\",\"wsServer\":\"ws://10.51.111.101/msgpush\",\"mupId\":\"63634f8844714aaebcb887fbc8af6782\",\"cookie\":\"JSESSIONID=CF423C13A709D1C0B69EA57D8CB24CF4;\",\"ccid\":\"e97be413e6cb495c8e83637eea98d6e8\",\"ccName\":\"CICI\"}";

cordova.plugins.MupMessagePlugin.initBasePlugin(() => {
             }, (e) => {
                 console.log(e)
             }, configInfo, userInfo);
```